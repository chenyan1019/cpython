from flask import Flask

raise ImportError()

testapp = Flask("testapp")
